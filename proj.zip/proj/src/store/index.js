import { createStore } from 'vuex'
//import userModule from './modules/userModule'
//import auctionsModule from './modules/auctionsModule'
//import bidsModule from './modules/bidsModule'

export const store = createStore({
    modules:{
        //userModule,
        //auctionsModule,
        //bidsModule
    }
})

