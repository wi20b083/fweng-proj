<template>
    
      <img src="../../assets/logo.png" alt="Logo" width="30" height="24">
    
</template>

<script>

export default{
   name:'AtomNavLogo'
}
</script>
